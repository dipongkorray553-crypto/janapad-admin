package com.janapad.admin

import android.app.Application
import com.google.firebase.FirebaseApp

class JanapadAdminApp : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            if (FirebaseApp.getApps(this).isEmpty()) {
                FirebaseApp.initializeApp(this)
            }
        } catch (_: Exception) {
            // Handled gracefully by FirebaseGuard
        }
    }
}
