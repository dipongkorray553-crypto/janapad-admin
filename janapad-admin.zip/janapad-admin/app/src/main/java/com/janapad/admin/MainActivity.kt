package com.janapad.admin

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.janapad.admin.ui.navigation.JanapadAdminAppScaffold
import com.janapad.admin.ui.theme.JanapadAdminTheme
import com.janapad.admin.ui.viewmodel.AdminViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: AdminViewModel = viewModel()
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            JanapadAdminTheme(themeMode = themeMode) {
                JanapadAdminAppScaffold(viewModel = viewModel)
            }
        }
    }
}
