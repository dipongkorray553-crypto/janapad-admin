package com.janapad.admin.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.janapad.admin.data.model.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.adminDataStore: DataStore<Preferences> by preferencesDataStore(name = "janapad_admin_prefs")

class PreferencesManager(private val context: Context) {
    private val themeKey = stringPreferencesKey("admin_theme_mode")

    val themeModeFlow: Flow<ThemeMode> = context.adminDataStore.data.map { prefs ->
        val raw = prefs[themeKey] ?: ThemeMode.SYSTEM.name
        runCatching { ThemeMode.valueOf(raw) }.getOrDefault(ThemeMode.SYSTEM)
    }

    suspend fun setThemeMode(mode: ThemeMode) {
        context.adminDataStore.edit { it[themeKey] = mode.name }
    }
}
