package com.janapad.admin.data.model

import com.google.firebase.firestore.PropertyName

sealed interface ResourceState<out T> {
    data object Loading : ResourceState<Nothing>
    data class Success<T>(val data: T) : ResourceState<T>
    data class Error(val message: String) : ResourceState<Nothing>
}

enum class ThemeMode(val labelBn: String) {
    SYSTEM("সিস্টেম"),
    LIGHT("লাইট"),
    DARK("ডার্ক")
}

data class UserProfile(
    val uid: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val role: String = "user",
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    val union: String = "",
    val ward: String = "",
    val village: String = "",
    val areaId: String = "patgram_lalmonirhat",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class PublicPost(
    val id: String = "",
    val authorId: String = "",
    val authorName: String = "",
    val authorPhone: String = "",
    val title: String = "",
    val content: String = "",
    val category: String = "সাধারণ",
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val status: String = "pending",
    val rejectionReason: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class NewsItem(
    val id: String = "",
    val title: String = "",
    val summary: String = "",
    val content: String = "",
    val category: String = "উপজেলা",
    @get:PropertyName("isPinned")
    @set:PropertyName("isPinned")
    var isPinned: Boolean = false,
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val authorName: String = "জনপদ ডেস্ক",
    val publishedAt: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

data class NoticeItem(
    val id: String = "",
    val title: String = "",
    val content: String = "",
    val priority: String = "normal",
    val department: String = "উপজেলা প্রশাসন",
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val validUntil: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class BloodDonor(
    val id: String = "",
    val userId: String = "",
    val name: String = "",
    val bloodGroup: String = "O+",
    val phone: String = "",
    val consentToShowPhone: Boolean = false,
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    val union: String = "",
    val village: String = "",
    val areaId: String = "patgram_lalmonirhat",
    @get:PropertyName("isAvailable")
    @set:PropertyName("isAvailable")
    var isAvailable: Boolean = true,
    val lastDonationDate: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

data class JobListing(
    val id: String = "",
    val title: String = "",
    val companyName: String = "",
    val category: String = "অন্যান্য",
    val salary: String = "আলোচনা সাপেক্ষে",
    val location: String = "পাটগ্রাম",
    val areaId: String = "patgram_lalmonirhat",
    val description: String = "",
    val requirements: String = "",
    val contactPhone: String = "",
    val contactEmail: String = "",
    val deadline: String = "",
    @get:PropertyName("isActive")
    @set:PropertyName("isActive")
    var isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)

data class MarketplaceItem(
    val id: String = "",
    val sellerId: String = "",
    val sellerName: String = "",
    val title: String = "",
    val description: String = "",
    val price: Long = 0L,
    val category: String = "অন্যান্য",
    val condition: String = "ব্যবহৃত",
    val location: String = "পাটগ্রাম",
    val areaId: String = "patgram_lalmonirhat",
    val sellerPhone: String = "",
    val status: String = "pending",
    val createdAt: Long = System.currentTimeMillis()
)

data class LostFoundItem(
    val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val type: String = "lost",
    val title: String = "",
    val description: String = "",
    val location: String = "",
    val areaId: String = "patgram_lalmonirhat",
    val dateText: String = "",
    val contactPhone: String = "",
    @get:PropertyName("isResolved")
    @set:PropertyName("isResolved")
    var isResolved: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class AreaReport(
    val id: String = "",
    val reporterId: String = "",
    val reporterName: String = "",
    val category: String = "road",
    val title: String = "",
    val description: String = "",
    val locationDetail: String = "",
    val areaId: String = "patgram_lalmonirhat",
    val areaName: String = "পাটগ্রাম, লালমনিরহাট",
    val status: String = "submitted",
    val adminNote: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class AppNotification(
    val id: String = "",
    val targetUserId: String = "all",
    val areaId: String = "patgram_lalmonirhat",
    val type: String = "news",
    val title: String = "",
    val message: String = "",
    val referenceId: String = "",
    @get:PropertyName("isRead")
    @set:PropertyName("isRead")
    var isRead: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

data class EmergencyContact(
    val id: String = "",
    val category: String = "গুরুত্বপূর্ণ নম্বর",
    val name: String = "",
    val phone: String = "",
    val address: String = "",
    @get:PropertyName("isVerified")
    @set:PropertyName("isVerified")
    var isVerified: Boolean = true
)

data class AreaInfo(
    val id: String = "patgram_lalmonirhat",
    val division: String = "রংপুর",
    val district: String = "লালমনিরহাট",
    val upazila: String = "পাটগ্রাম",
    @get:PropertyName("isActive")
    @set:PropertyName("isActive")
    var isActive: Boolean = true,
    val description: String = "",
    val unions: List<String> = emptyList(),
    val emergencyContacts: List<EmergencyContact> = emptyList()
)

object AdminCatalog {
    val newsCategories = listOf("জরুরি", "উপজেলা", "শিক্ষা", "কৃষি", "উন্নয়ন", "খেলাধুলা")
    val jobCategories = listOf("শিক্ষা", "অফিস", "ব্যবসা ও সেলস", "আইটি ও ডিজিটাল", "স্বাস্থ্য", "অন্যান্য")
    val emergencyCategories = listOf("হাসপাতাল", "অ্যাম্বুলেন্স", "ফায়ার সার্ভিস", "পুলিশ", "গুরুত্বপূর্ণ নম্বর")
    val reportStatuses = listOf(
        "submitted" to "জমা হয়েছে",
        "in_review" to "পর্যালোচনাধীন",
        "in_progress" to "কাজ চলছে",
        "resolved" to "সমাধান হয়েছে",
        "rejected" to "প্রত্যাখ্যাত"
    )

    fun reportCategoryLabel(code: String): String = when (code) {
        "road" -> "রাস্তাঘাট সমস্যা"
        "electricity" -> "বিদ্যুৎ সমস্যা"
        "water" -> "পানি সরবরাহ"
        "drainage" -> "ড্রেনেজ ও জলাবদ্ধতা"
        else -> "জনসেবা অভিযোগ"
    }

    fun reportStatusLabel(status: String): String {
        return reportStatuses.firstOrNull { it.first == status }?.second ?: status
    }
}
