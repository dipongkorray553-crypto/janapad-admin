package com.janapad.admin.data.repository

import android.content.Context
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.janapad.admin.data.model.UserProfile
import kotlinx.coroutines.tasks.await

class AdminAuthRepository(private val context: Context) {

    val isFirebaseReady: Boolean
        get() = FirebaseGuard.isConfigured(context)

    private val auth: FirebaseAuth?
        get() = if (isFirebaseReady) FirebaseAuth.getInstance() else null

    private val db: FirebaseFirestore?
        get() = if (isFirebaseReady) FirebaseFirestore.getInstance() else null

    val currentUser: FirebaseUser?
        get() = auth?.currentUser

    suspend fun verifyCurrentAdminSession(): Result<UserProfile?> {
        val fbUser = auth?.currentUser ?: return Result.success(null)
        return verifyAdminPrivileges(fbUser)
    }

    suspend fun loginAdmin(email: String, password: String): Result<UserProfile> {
        val firebaseAuth = auth ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val res = firebaseAuth.signInWithEmailAndPassword(email.trim(), password).await()
            val fbUser = res.user ?: return Result.failure(Exception("লগইন সম্পন্ন হয়নি।"))
            val verified = verifyAdminPrivileges(fbUser).getOrThrow()
            if (verified != null) {
                Result.success(verified)
            } else {
                firebaseAuth.signOut()
                Result.failure(Exception("অ্যাডমিন অনুমোদন পাওয়া যায়নি।"))
            }
        } catch (e: Exception) {
            Result.failure(Exception(mapError(e)))
        }
    }

    private suspend fun verifyAdminPrivileges(fbUser: FirebaseUser): Result<UserProfile?> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val tokenResult = fbUser.getIdToken(true).await()
            val hasAdminClaim = tokenResult.claims["admin"] == true

            val snap = firestore.collection("users").document(fbUser.uid).get().await()
            val profile = snap.toObject(UserProfile::class.java)

            if (hasAdminClaim || profile?.role == "admin") {
                val safeProfile = profile ?: UserProfile(
                    uid = fbUser.uid,
                    name = fbUser.displayName?.ifBlank { "JANAPAD Admin" } ?: "JANAPAD Admin",
                    email = fbUser.email ?: "",
                    role = "admin"
                )
                Result.success(safeProfile)
            } else {
                auth?.signOut()
                Result.failure(
                    Exception(
                        "এই অ্যাকাউন্টটি অ্যাডমিন হিসেবে অনুমোদিত নয়। Firebase Console → Firestore → users/${fbUser.uid} ডকুমেন্টে role এর মান \"admin\" করে আবার লগইন করুন।"
                    )
                )
            }
        } catch (e: Exception) {
            Result.failure(Exception("অ্যাডমিন যাচাই ব্যর্থ হয়েছে: ${e.localizedMessage ?: "নেটওয়ার্ক ত্রুটি"}"))
        }
    }

    fun logout() {
        auth?.signOut()
    }

    private fun mapError(e: Exception): String {
        val msg = e.localizedMessage.orEmpty()
        return when {
            msg.contains("password is invalid", true) ||
                msg.contains("INVALID_LOGIN_CREDENTIALS", true) ||
                msg.contains("credential is incorrect", true) ->
                "ইমেইল অথবা পাসওয়ার্ড সঠিক নয়।"
            msg.contains("no user record", true) ->
                "এই ইমেইলে কোনো অ্যাকাউন্ট পাওয়া যায়নি।"
            msg.contains("network error", true) ->
                "ইন্টারনেট সংযোগ পরীক্ষা করুন।"
            else -> msg.ifBlank { "লগইন ব্যর্থ হয়েছে।" }
        }
    }
}
