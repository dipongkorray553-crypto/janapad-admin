package com.janapad.admin.data.repository

import android.content.Context
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.janapad.admin.data.model.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await

class AdminRepository(private val context: Context) {

    val isFirebaseReady: Boolean
        get() = FirebaseGuard.isConfigured(context)

    private val db: FirebaseFirestore?
        get() = if (isFirebaseReady) FirebaseFirestore.getInstance() else null

    private inline fun <reified T : Any> observeCollection(
        collectionName: String,
        crossinline mapDoc: (String, T) -> T,
        crossinline sortKey: (T) -> Long
    ): Flow<ResourceState<List<T>>> {
        val firestore = db ?: return flowOf(ResourceState.Error(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return callbackFlow {
            trySend(ResourceState.Loading)
            val reg: ListenerRegistration = firestore.collection(collectionName)
                .limit(200)
                .addSnapshotListener { snap, err ->
                    if (err != null) {
                        trySend(ResourceState.Error("লোড ব্যর্থ ($collectionName): ${err.localizedMessage ?: "ত্রুটি"}"))
                        return@addSnapshotListener
                    }
                    val list = snap?.documents?.mapNotNull { doc ->
                        doc.toObject(T::class.java)?.let { mapDoc(doc.id, it) }
                    }?.sortedByDescending { sortKey(it) } ?: emptyList()
                    trySend(ResourceState.Success(list))
                }
            awaitClose { reg.remove() }
        }
    }

    // ---------- OBSERVERS ----------
    fun observePosts() = observeCollection<PublicPost>("posts", { id, x -> x.copy(id = id) }, { it.createdAt })
    fun observeNews() = observeCollection<NewsItem>("news", { id, x -> x.copy(id = id) }, { it.publishedAt })
    fun observeNotices() = observeCollection<NoticeItem>("notices", { id, x -> x.copy(id = id) }, { it.createdAt })
    fun observeJobs() = observeCollection<JobListing>("jobs", { id, x -> x.copy(id = id) }, { it.createdAt })
    fun observeMarketplace() = observeCollection<MarketplaceItem>("marketplace", { id, x -> x.copy(id = id) }, { it.createdAt })
    fun observeReports() = observeCollection<AreaReport>("reports", { id, x -> x.copy(id = id) }, { it.createdAt })
    fun observeAreas() = observeCollection<AreaInfo>("areas", { id, x -> x.copy(id = id) }, { if (it.id == "patgram_lalmonirhat") Long.MAX_VALUE else 0L })
    fun observeNotifications() = observeCollection<AppNotification>("notifications", { id, x -> x.copy(id = id) }, { it.createdAt })
    fun observeUsers() = observeCollection<UserProfile>("users", { id, x -> x.copy(uid = id) }, { it.createdAt })
    fun observeBloodDonors() = observeCollection<BloodDonor>("blood_donors", { id, x -> x.copy(id = id) }, { it.updatedAt })
    fun observeLostFound() = observeCollection<LostFoundItem>("lost_found", { id, x -> x.copy(id = id) }, { it.createdAt })

    // ---------- POSTS MODERATION ----------
    suspend fun updatePostStatus(post: PublicPost, status: String, rejectionReason: String = ""): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val now = System.currentTimeMillis()
            firestore.collection("posts").document(post.id).update(
                mapOf(
                    "status" to status,
                    "rejectionReason" to rejectionReason.trim(),
                    "updatedAt" to now
                )
            ).await()

            // Auto-notify post author
            val notifTitle = if (status == "approved") "আপনার পোস্ট প্রকাশিত হয়েছে" else "আপনার পোস্ট বাতিল হয়েছে"
            val notifMsg = if (status == "approved") {
                "\"${post.title}\" পোস্টটি অ্যাডমিন অনুমোদন করেছেন।"
            } else {
                "\"${post.title}\" পোস্টটি বাতিল হয়েছে। কারণ: ${rejectionReason.ifBlank { "কমিউনিটি নীতিমালা" }}"
            }
            sendNotificationInternal(
                firestore = firestore,
                targetUserId = post.authorId,
                areaId = post.areaId,
                type = "post_status",
                title = notifTitle,
                message = notifMsg,
                referenceId = post.id
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteDocument(collection: String, docId: String): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection(collection).document(docId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- NEWS ----------
    suspend fun saveNews(item: NewsItem, broadcastNotification: Boolean): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val ref = if (item.id.isBlank()) firestore.collection("news").document() else firestore.collection("news").document(item.id)
            val now = System.currentTimeMillis()
            val finalItem = item.copy(
                id = ref.id,
                publishedAt = if (item.id.isBlank()) now else item.publishedAt,
                createdAt = if (item.id.isBlank()) now else item.createdAt
            )
            ref.set(finalItem).await()
            if (broadcastNotification) {
                sendNotificationInternal(
                    firestore = firestore,
                    targetUserId = "all",
                    areaId = finalItem.areaId,
                    type = "news",
                    title = "নতুন সংবাদ: ${finalItem.title}",
                    message = finalItem.summary.ifBlank { finalItem.content.take(120) },
                    referenceId = finalItem.id
                )
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleNewsPin(newsId: String, isPinned: Boolean): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection("news").document(newsId).update("isPinned", isPinned).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- NOTICES ----------
    suspend fun saveNotice(item: NoticeItem, broadcastNotification: Boolean): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val ref = if (item.id.isBlank()) firestore.collection("notices").document() else firestore.collection("notices").document(item.id)
            val finalItem = item.copy(id = ref.id, createdAt = if (item.id.isBlank()) System.currentTimeMillis() else item.createdAt)
            ref.set(finalItem).await()
            if (broadcastNotification) {
                sendNotificationInternal(
                    firestore = firestore,
                    targetUserId = "all",
                    areaId = finalItem.areaId,
                    type = "notice",
                    title = if (finalItem.priority == "high") "জরুরি নোটিশ: ${finalItem.title}" else "নোটিশ: ${finalItem.title}",
                    message = finalItem.content.take(140),
                    referenceId = finalItem.id
                )
            }
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- JOBS ----------
    suspend fun saveJob(item: JobListing): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val ref = if (item.id.isBlank()) firestore.collection("jobs").document() else firestore.collection("jobs").document(item.id)
            val finalItem = item.copy(id = ref.id, createdAt = if (item.id.isBlank()) System.currentTimeMillis() else item.createdAt)
            ref.set(finalItem).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleJobActive(jobId: String, active: Boolean): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection("jobs").document(jobId).update("isActive", active).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- MARKETPLACE MODERATION ----------
    suspend fun updateMarketplaceStatus(item: MarketplaceItem, status: String): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection("marketplace").document(item.id).update("status", status).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- REPORTS MANAGEMENT ----------
    suspend fun updateReportStatus(report: AreaReport, status: String, adminNote: String): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            firestore.collection("reports").document(report.id).update(
                mapOf(
                    "status" to status,
                    "adminNote" to adminNote.trim(),
                    "updatedAt" to System.currentTimeMillis()
                )
            ).await()
            sendNotificationInternal(
                firestore = firestore,
                targetUserId = report.reporterId,
                areaId = report.areaId,
                type = "report_status",
                title = "আপনার রিপোর্টের স্ট্যাটাস আপডেট হয়েছে",
                message = "\"${report.title}\" — নতুন অবস্থা: ${AdminCatalog.reportStatusLabel(status)}${if (adminNote.isNotBlank()) "। মন্তব্য: $adminNote" else ""}",
                referenceId = report.id
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- AREAS & EMERGENCY CONTACTS ----------
    suspend fun saveArea(area: AreaInfo): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            val safeId = area.id.ifBlank {
                "${area.upazila}_${area.district}".lowercase().replace(" ", "_")
            }
            firestore.collection("areas").document(safeId).set(area.copy(id = safeId)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------- BROADCAST NOTIFICATION ----------
    suspend fun sendBroadcastNotification(title: String, message: String, type: String, areaId: String = "patgram_lalmonirhat"): Result<Unit> {
        val firestore = db ?: return Result.failure(IllegalStateException(FirebaseGuard.NOT_CONFIGURED_MESSAGE))
        return try {
            sendNotificationInternal(firestore, "all", areaId, type, title.trim(), message.trim(), "")
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun sendNotificationInternal(
        firestore: FirebaseFirestore,
        targetUserId: String,
        areaId: String,
        type: String,
        title: String,
        message: String,
        referenceId: String
    ) {
        val ref = firestore.collection("notifications").document()
        val notif = AppNotification(
            id = ref.id,
            targetUserId = targetUserId,
            areaId = areaId,
            type = type,
            title = title,
            message = message,
            referenceId = referenceId,
            isRead = false,
            createdAt = System.currentTimeMillis()
        )
        ref.set(notif).await()
    }
}
