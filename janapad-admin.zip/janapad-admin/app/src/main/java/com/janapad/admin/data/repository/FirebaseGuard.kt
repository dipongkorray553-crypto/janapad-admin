package com.janapad.admin.data.repository

import android.content.Context
import com.google.firebase.FirebaseApp

object FirebaseGuard {
    fun isConfigured(context: Context): Boolean {
        return try {
            FirebaseApp.getApps(context).isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    const val NOT_CONFIGURED_MESSAGE =
        "Firebase কনফিগার করা হয়নি। আপনার Firebase Console-এ com.janapad.admin অ্যাপ যুক্ত করে google-services.json ডাউনলোড করে GitHub Secret (GOOGLE_SERVICES_JSON)-এ দিন।"
}
