package com.janapad.admin.ui.navigation

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.janapad.admin.data.model.ThemeMode
import com.janapad.admin.ui.screens.*
import com.janapad.admin.ui.viewmodel.AdminViewModel

object AdminRoutes {
    const val DASHBOARD = "dashboard"
    const val MODERATION = "moderation"
    const val CONTENT = "content"
    const val REPORTS = "reports"
    const val AREAS = "areas"
    const val BROADCAST = "broadcast"
    const val USERS_DONORS = "users_donors"
}

private data class AdminTab(val route: String, val label: String, val icon: ImageVector)

@Composable
fun JanapadAdminAppScaffold(viewModel: AdminViewModel) {
    val authState by viewModel.authState.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()

    if (authState.isCheckingSession) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator()
        }
        return
    }

    if (!authState.isAuthenticatedAdmin) {
        AdminLoginScreen(
            uiState = authState,
            onLogin = viewModel::loginAdmin
        )
        return
    }

    val navController = rememberNavController()
    val postsState by viewModel.posts.collectAsStateWithLifecycle()
    val newsState by viewModel.news.collectAsStateWithLifecycle()
    val noticesState by viewModel.notices.collectAsStateWithLifecycle()
    val jobsState by viewModel.jobs.collectAsStateWithLifecycle()
    val marketplaceState by viewModel.marketplace.collectAsStateWithLifecycle()
    val reportsState by viewModel.reports.collectAsStateWithLifecycle()
    val areasState by viewModel.areas.collectAsStateWithLifecycle()
    val notificationsState by viewModel.notifications.collectAsStateWithLifecycle()
    val usersState by viewModel.users.collectAsStateWithLifecycle()
    val donorsState by viewModel.bloodDonors.collectAsStateWithLifecycle()
    val lostFoundState by viewModel.lostFound.collectAsStateWithLifecycle()

    val tabs = remember {
        listOf(
            AdminTab(AdminRoutes.DASHBOARD, "ড্যাশবোর্ড", Icons.Rounded.Dashboard),
            AdminTab(AdminRoutes.MODERATION, "অনুমোদন", Icons.Rounded.FactCheck),
            AdminTab(AdminRoutes.CONTENT, "প্রকাশনা", Icons.Rounded.Newspaper),
            AdminTab(AdminRoutes.REPORTS, "রিপোর্ট", Icons.Rounded.ReportProblem)
        )
    }
    val tabRoutes = remember { tabs.map { it.route }.toSet() }
    val backStack by navController.currentBackStackEntryAsState()
    val currentRoute = backStack?.destination?.route

    fun go(route: String) {
        if (route in tabRoutes) {
            navController.navigate(route) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
            }
        } else {
            navController.navigate(route) { launchSingleTop = true }
        }
    }

    Scaffold(
        bottomBar = {
            if (currentRoute in tabRoutes) {
                NavigationBar {
                    tabs.forEach { tab ->
                        NavigationBarItem(
                            selected = currentRoute == tab.route,
                            onClick = { go(tab.route) },
                            icon = { Icon(tab.icon, contentDescription = tab.label) },
                            label = { Text(tab.label, style = MaterialTheme.typography.labelSmall) }
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = AdminRoutes.DASHBOARD,
            modifier = Modifier.padding(bottom = padding.calculateBottomPadding())
        ) {
            composable(AdminRoutes.DASHBOARD) {
                DashboardScreen(
                    adminProfile = authState.adminProfile,
                    themeMode = themeMode,
                    postsState = postsState,
                    marketplaceState = marketplaceState,
                    reportsState = reportsState,
                    newsState = newsState,
                    noticesState = noticesState,
                    jobsState = jobsState,
                    usersState = usersState,
                    donorsState = donorsState,
                    onToggleTheme = {
                        viewModel.setThemeMode(if (themeMode == ThemeMode.DARK) ThemeMode.LIGHT else ThemeMode.DARK)
                    },
                    onNavigate = { go(it) },
                    onLogout = viewModel::logout
                )
            }

            composable(AdminRoutes.MODERATION) {
                ModerationScreen(
                    postsState = postsState,
                    marketplaceState = marketplaceState,
                    onApprovePost = viewModel::approvePost,
                    onRejectPost = viewModel::rejectPost,
                    onDeletePost = { id, cb -> viewModel.deleteDoc("posts", id, cb) },
                    onUpdateMarketplaceStatus = viewModel::updateMarketplaceStatus,
                    onDeleteMarketplace = { id, cb -> viewModel.deleteDoc("marketplace", id, cb) },
                    onRetry = viewModel::startListeners
                )
            }

            composable(AdminRoutes.CONTENT) {
                ContentManagerScreen(
                    newsState = newsState,
                    noticesState = noticesState,
                    jobsState = jobsState,
                    onSaveNews = viewModel::saveNews,
                    onToggleNewsPin = viewModel::toggleNewsPin,
                    onDeleteNews = { id, cb -> viewModel.deleteDoc("news", id, cb) },
                    onSaveNotice = viewModel::saveNotice,
                    onDeleteNotice = { id, cb -> viewModel.deleteDoc("notices", id, cb) },
                    onSaveJob = viewModel::saveJob,
                    onToggleJobActive = viewModel::toggleJobActive,
                    onDeleteJob = { id, cb -> viewModel.deleteDoc("jobs", id, cb) },
                    onRetry = viewModel::startListeners
                )
            }

            composable(AdminRoutes.REPORTS) {
                ReportsManagerScreen(
                    reportsState = reportsState,
                    onUpdateReport = viewModel::updateReportStatus,
                    onDeleteReport = { id, cb -> viewModel.deleteDoc("reports", id, cb) },
                    onRetry = viewModel::startListeners
                )
            }

            composable(AdminRoutes.AREAS) {
                AreasManagerScreen(
                    areasState = areasState,
                    onSaveArea = viewModel::saveArea,
                    onRetry = viewModel::startListeners,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(AdminRoutes.BROADCAST) {
                BroadcastScreen(
                    notificationsState = notificationsState,
                    onSendBroadcast = viewModel::sendBroadcast,
                    onDeleteNotification = { id, cb -> viewModel.deleteDoc("notifications", id, cb) },
                    onRetry = viewModel::startListeners,
                    onBack = { navController.popBackStack() }
                )
            }

            composable(AdminRoutes.USERS_DONORS) {
                UsersDonorsScreen(
                    usersState = usersState,
                    donorsState = donorsState,
                    lostFoundState = lostFoundState,
                    onDeleteLostFound = { id, cb -> viewModel.deleteDoc("lost_found", id, cb) },
                    onRetry = viewModel::startListeners,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
