package com.janapad.admin.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.janapad.admin.data.model.*
import com.janapad.admin.ui.components.*
import com.janapad.admin.ui.theme.DangerRed
import com.janapad.admin.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContentManagerScreen(
    newsState: ResourceState<List<NewsItem>>,
    noticesState: ResourceState<List<NoticeItem>>,
    jobsState: ResourceState<List<JobListing>>,
    onSaveNews: (NewsItem, Boolean, (Boolean, String) -> Unit) -> Unit,
    onToggleNewsPin: (String, Boolean) -> Unit,
    onDeleteNews: (String, (Boolean, String) -> Unit) -> Unit,
    onSaveNotice: (NoticeItem, Boolean, (Boolean, String) -> Unit) -> Unit,
    onDeleteNotice: (String, (Boolean, String) -> Unit) -> Unit,
    onSaveJob: (JobListing, (Boolean, String) -> Unit) -> Unit,
    onToggleJobActive: (String, Boolean) -> Unit,
    onDeleteJob: (String, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var showCreateDialog by remember { mutableStateOf(false) }

    val fabLabel = when (tab) {
        0 -> "নতুন সংবাদ"
        1 -> "নতুন নোটিশ"
        else -> "নতুন চাকরি"
    }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("সংবাদ, নোটিশ ও চাকরি", fontWeight = FontWeight.Bold) })
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateDialog = true },
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text(fabLabel) }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("সংবাদ") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("নোটিশ") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("চাকরি") })
            }

            when (tab) {
                0 -> when (newsState) {
                    is ResourceState.Loading -> AdminLoadingView("সংবাদ লোড হচ্ছে...")
                    is ResourceState.Error -> AdminErrorView(newsState.message, onRetry)
                    is ResourceState.Success -> {
                        if (newsState.data.isEmpty()) {
                            AdminEmptyView(Icons.Rounded.Newspaper, "কোনো সংবাদ নেই", "নিচের বাটনে চাপ দিয়ে প্রথম সংবাদ প্রকাশ করুন।")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 84.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(newsState.data, key = { it.id }) { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                                    StatusChip(item.category, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                                                    if (item.isPinned) StatusChip("পিনকৃত", MaterialTheme.colorScheme.errorContainer, DangerRed)
                                                }
                                                Row {
                                                    IconButton(onClick = { onToggleNewsPin(item.id, !item.isPinned) }) {
                                                        Icon(
                                                            Icons.Rounded.PushPin,
                                                            contentDescription = "পিন",
                                                            tint = if (item.isPinned) DangerRed else MaterialTheme.colorScheme.onSurfaceVariant
                                                        )
                                                    }
                                                    IconButton(onClick = {
                                                        onDeleteNews(item.id) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                                    }) {
                                                        Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                                    }
                                                }
                                            }
                                            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(item.summary.ifBlank { item.content }, style = MaterialTheme.typography.bodySmall, maxLines = 3)
                                            Text(formatDateBn(item.publishedAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                1 -> when (noticesState) {
                    is ResourceState.Loading -> AdminLoadingView("নোটিশ লোড হচ্ছে...")
                    is ResourceState.Error -> AdminErrorView(noticesState.message, onRetry)
                    is ResourceState.Success -> {
                        if (noticesState.data.isEmpty()) {
                            AdminEmptyView(Icons.Rounded.Campaign, "কোনো নোটিশ নেই", "জরুরি বা সাধারণ নোটিশ প্রকাশ করুন।")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 84.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(noticesState.data, key = { it.id }) { notice ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                StatusChip(
                                                    if (notice.priority == "high") "জরুরি নোটিশ" else notice.department,
                                                    if (notice.priority == "high") MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.primaryContainer,
                                                    if (notice.priority == "high") DangerRed else MaterialTheme.colorScheme.onPrimaryContainer
                                                )
                                                IconButton(onClick = {
                                                    onDeleteNotice(notice.id) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                                }) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                                }
                                            }
                                            Text(notice.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(notice.content, style = MaterialTheme.typography.bodySmall)
                                            if (notice.validUntil.isNotBlank()) {
                                                Text("মেয়াদ: ${notice.validUntil}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> when (jobsState) {
                    is ResourceState.Loading -> AdminLoadingView("চাকরি লোড হচ্ছে...")
                    is ResourceState.Error -> AdminErrorView(jobsState.message, onRetry)
                    is ResourceState.Success -> {
                        if (jobsState.data.isEmpty()) {
                            AdminEmptyView(Icons.Rounded.Work, "কোনো চাকরির বিজ্ঞপ্তি নেই", "স্থানীয় চাকরির বিজ্ঞপ্তি যুক্ত করুন।")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 84.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(jobsState.data, key = { it.id }) { job ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                StatusChip(
                                                    if (job.isActive) "চালু" else "বন্ধ",
                                                    if (job.isActive) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                                    if (job.isActive) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                                )
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Switch(checked = job.isActive, onCheckedChange = { onToggleJobActive(job.id, it) })
                                                    IconButton(onClick = {
                                                        onDeleteJob(job.id) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                                    }) {
                                                        Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                                    }
                                                }
                                            }
                                            Text(job.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text("${job.companyName} • ${job.location} • ${job.salary}", style = MaterialTheme.typography.bodySmall)
                                            if (job.deadline.isNotBlank()) {
                                                Text("শেষ তারিখ: ${job.deadline}", style = MaterialTheme.typography.labelSmall, color = DangerRed)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        when (tab) {
            0 -> CreateNewsDialog(
                onDismiss = { showCreateDialog = false },
                onSave = { item, broadcast ->
                    onSaveNews(item, broadcast) { ok, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (ok) showCreateDialog = false
                    }
                }
            )
            1 -> CreateNoticeDialog(
                onDismiss = { showCreateDialog = false },
                onSave = { item, broadcast ->
                    onSaveNotice(item, broadcast) { ok, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (ok) showCreateDialog = false
                    }
                }
            )
            else -> CreateJobDialog(
                onDismiss = { showCreateDialog = false },
                onSave = { item ->
                    onSaveJob(item) { ok, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (ok) showCreateDialog = false
                    }
                }
            )
        }
    }
}

@Composable
private fun CreateNewsDialog(onDismiss: () -> Unit, onSave: (NewsItem, Boolean) -> Unit) {
    val context = LocalContext.current
    var category by remember { mutableStateOf(AdminCatalog.newsCategories.first()) }
    var title by remember { mutableStateOf("") }
    var summary by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var author by remember { mutableStateOf("জনপদ ডেস্ক") }
    var isPinned by remember { mutableStateOf(false) }
    var broadcast by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন সংবাদ প্রকাশ", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(AdminCatalog.newsCategories) { cat ->
                        FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম *") }, singleLine = true)
                OutlinedTextField(value = summary, onValueChange = { summary = it }, label = { Text("সংক্ষিপ্ত সারাংশ") }, maxLines = 2)
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("বিস্তারিত সংবাদ *") }, minLines = 4)
                OutlinedTextField(value = author, onValueChange = { author = it }, label = { Text("প্রকাশক / ডেস্ক") }, singleLine = true)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = isPinned, onCheckedChange = { isPinned = it })
                    Text("গুরুত্বপূর্ণ হিসেবে পিন করুন", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = broadcast, onCheckedChange = { broadcast = it })
                    Text("সব ব্যবহারকারীকে নোটিফিকেশন পাঠান", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank() || content.isBlank()) {
                    Toast.makeText(context, "শিরোনাম ও বিস্তারিত লিখুন।", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                onSave(
                    NewsItem(
                        title = title.trim(),
                        summary = summary.trim(),
                        content = content.trim(),
                        category = category,
                        isPinned = isPinned,
                        authorName = author.trim().ifBlank { "জনপদ ডেস্ক" }
                    ),
                    broadcast
                )
            }) { Text("প্রকাশ করুন") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun CreateNoticeDialog(onDismiss: () -> Unit, onSave: (NoticeItem, Boolean) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var department by remember { mutableStateOf("উপজেলা প্রশাসন") }
    var validUntil by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var highPriority by remember { mutableStateOf(false) }
    var broadcast by remember { mutableStateOf(true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন নোটিশ প্রকাশ", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("নোটিশের শিরোনাম *") }, singleLine = true)
                OutlinedTextField(value = department, onValueChange = { department = it }, label = { Text("দপ্তর / কর্তৃপক্ষ") }, singleLine = true)
                OutlinedTextField(value = validUntil, onValueChange = { validUntil = it }, label = { Text("মেয়াদ (ঐচ্ছিক)") }, singleLine = true)
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("নোটিশের বিস্তারিত *") }, minLines = 4)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = highPriority, onCheckedChange = { highPriority = it })
                    Text("জরুরি নোটিশ (High Priority)", style = MaterialTheme.typography.bodySmall)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = broadcast, onCheckedChange = { broadcast = it })
                    Text("সব ব্যবহারকারীকে নোটিফিকেশন পাঠান", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank() || content.isBlank()) {
                    Toast.makeText(context, "শিরোনাম ও বিস্তারিত লিখুন।", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                onSave(
                    NoticeItem(
                        title = title.trim(),
                        content = content.trim(),
                        department = department.trim().ifBlank { "উপজেলা প্রশাসন" },
                        priority = if (highPriority) "high" else "normal",
                        validUntil = validUntil.trim()
                    ),
                    broadcast
                )
            }) { Text("প্রকাশ করুন") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}

@Composable
private fun CreateJobDialog(onDismiss: () -> Unit, onSave: (JobListing) -> Unit) {
    val context = LocalContext.current
    var category by remember { mutableStateOf(AdminCatalog.jobCategories.first()) }
    var title by remember { mutableStateOf("") }
    var company by remember { mutableStateOf("") }
    var salary by remember { mutableStateOf("আলোচনা সাপেক্ষে") }
    var location by remember { mutableStateOf("পাটগ্রাম") }
    var phone by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var deadline by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var requirements by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("নতুন চাকরির বিজ্ঞপ্তি", fontWeight = FontWeight.Bold) },
        text = {
            Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(AdminCatalog.jobCategories) { cat ->
                        FilterChip(selected = category == cat, onClick = { category = cat }, label = { Text(cat) })
                    }
                }
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("পদের নাম *") }, singleLine = true)
                OutlinedTextField(value = company, onValueChange = { company = it }, label = { Text("প্রতিষ্ঠানের নাম *") }, singleLine = true)
                OutlinedTextField(value = salary, onValueChange = { salary = it }, label = { Text("বেতন") }, singleLine = true)
                OutlinedTextField(value = location, onValueChange = { location = it }, label = { Text("কর্মস্থল") }, singleLine = true)
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("যোগাযোগের ফোন") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("আবেদনের ইমেইল") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                    singleLine = true
                )
                OutlinedTextField(value = deadline, onValueChange = { deadline = it }, label = { Text("শেষ তারিখ") }, singleLine = true)
                OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("কাজের বিবরণ *") }, minLines = 3)
                OutlinedTextField(value = requirements, onValueChange = { requirements = it }, label = { Text("যোগ্যতা ও শর্তাবলি") }, minLines = 2)
            }
        },
        confirmButton = {
            Button(onClick = {
                if (title.isBlank() || company.isBlank() || description.isBlank()) {
                    Toast.makeText(context, "পদের নাম, প্রতিষ্ঠান ও বিবরণ লিখুন।", Toast.LENGTH_SHORT).show()
                    return@Button
                }
                onSave(
                    JobListing(
                        title = title.trim(),
                        companyName = company.trim(),
                        category = category,
                        salary = salary.trim(),
                        location = location.trim(),
                        contactPhone = phone.trim(),
                        contactEmail = email.trim(),
                        deadline = deadline.trim(),
                        description = description.trim(),
                        requirements = requirements.trim(),
                        isActive = true
                    )
                )
            }) { Text("প্রকাশ করুন") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("বাতিল") } }
    )
}
