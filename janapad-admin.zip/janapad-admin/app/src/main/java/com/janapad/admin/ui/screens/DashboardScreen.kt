package com.janapad.admin.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.admin.data.model.*
import com.janapad.admin.ui.navigation.AdminRoutes
import com.janapad.admin.ui.theme.*

@Composable
fun DashboardScreen(
    adminProfile: UserProfile?,
    themeMode: ThemeMode,
    postsState: ResourceState<List<PublicPost>>,
    marketplaceState: ResourceState<List<MarketplaceItem>>,
    reportsState: ResourceState<List<AreaReport>>,
    newsState: ResourceState<List<NewsItem>>,
    noticesState: ResourceState<List<NoticeItem>>,
    jobsState: ResourceState<List<JobListing>>,
    usersState: ResourceState<List<UserProfile>>,
    donorsState: ResourceState<List<BloodDonor>>,
    onToggleTheme: () -> Unit,
    onNavigate: (String) -> Unit,
    onLogout: () -> Unit
) {
    val pendingPosts = (postsState as? ResourceState.Success)?.data?.count { it.status == "pending" } ?: 0
    val pendingMarket = (marketplaceState as? ResourceState.Success)?.data?.count { it.status == "pending" } ?: 0
    val openReports = (reportsState as? ResourceState.Success)?.data?.count { it.status == "submitted" || it.status == "in_review" || it.status == "in_progress" } ?: 0
    val totalUsers = (usersState as? ResourceState.Success)?.data?.size ?: 0
    val totalDonors = (donorsState as? ResourceState.Success)?.data?.size ?: 0
    val totalNews = (newsState as? ResourceState.Success)?.data?.size ?: 0
    val totalNotices = (noticesState as? ResourceState.Success)?.data?.size ?: 0
    val totalJobs = (jobsState as? ResourceState.Success)?.data?.size ?: 0

    var showLogoutDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(listOf(NavyPrimary, NavyDark)),
                        shape = RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp)
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 18.dp, vertical = 20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "JANAPAD ADMIN",
                            style = MaterialTheme.typography.titleLarge,
                            color = GoldAccent,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = adminProfile?.name?.ifBlank { adminProfile.email } ?: "অ্যাডমিন প্যানেল",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        IconButton(
                            onClick = onToggleTheme,
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.14f),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                if (themeMode == ThemeMode.DARK) Icons.Rounded.LightMode else Icons.Rounded.DarkMode,
                                contentDescription = "থিম"
                            )
                        }
                        IconButton(
                            onClick = { showLogoutDialog = true },
                            colors = IconButtonDefaults.iconButtonColors(
                                containerColor = Color.White.copy(alpha = 0.14f),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.Logout, contentDescription = "লগআউট")
                        }
                    }
                }
            }
        }

        // Urgent Moderation KPIs
        item {
            Text(
                text = "তাৎক্ষণিক পর্যালোচনা (Pending Queue)",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                KpiCard(
                    title = "পেন্ডিং পোস্ট",
                    value = "$pendingPosts",
                    icon = Icons.Rounded.Forum,
                    accent = WarningAmber,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminRoutes.MODERATION) }
                )
                KpiCard(
                    title = "পেন্ডিং পণ্য",
                    value = "$pendingMarket",
                    icon = Icons.Rounded.Storefront,
                    accent = InfoBlue,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminRoutes.MODERATION) }
                )
                KpiCard(
                    title = "চলমান রিপোর্ট",
                    value = "$openReports",
                    icon = Icons.Rounded.ReportProblem,
                    accent = DangerRed,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigate(AdminRoutes.REPORTS) }
                )
            }
        }

        // Overview Stats
        item {
            Text(
                text = "সামগ্রিক পরিসংখ্যান",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(10.dp))
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    KpiCard("মোট ব্যবহারকারী", "$totalUsers", Icons.Rounded.People, NavyPrimary, Modifier.weight(1f)) {
                        onNavigate(AdminRoutes.USERS_DONORS)
                    }
                    KpiCard("রক্তদাতা", "$totalDonors", Icons.Rounded.Bloodtype, DangerRed, Modifier.weight(1f)) {
                        onNavigate(AdminRoutes.USERS_DONORS)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    KpiCard("সংবাদ", "$totalNews", Icons.Rounded.Newspaper, SuccessGreen, Modifier.weight(1f)) {
                        onNavigate(AdminRoutes.CONTENT)
                    }
                    KpiCard("নোটিশ ও চাকরি", "${totalNotices + totalJobs}", Icons.Rounded.Campaign, InfoBlue, Modifier.weight(1f)) {
                        onNavigate(AdminRoutes.CONTENT)
                    }
                }
            }
        }

        // Management Shortcuts
        item {
            Text(
                text = "দ্রুত নিয়ন্ত্রণ মেনু",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(
                modifier = Modifier.padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                AdminActionRow(
                    icon = Icons.Rounded.Newspaper,
                    title = "সংবাদ, নোটিশ ও চাকরি প্রকাশ",
                    subtitle = "নতুন সংবাদ পিন করা, জরুরি নোটিশ ও চাকরির বিজ্ঞপ্তি",
                    color = SuccessGreen,
                    onClick = { onNavigate(AdminRoutes.CONTENT) }
                )
                AdminActionRow(
                    icon = Icons.Rounded.Map,
                    title = "এলাকা ও জরুরি নম্বর ম্যানেজার",
                    subtitle = "পাটগ্রাম ও নতুন উপজেলা, ইউনিয়ন এবং স্থানীয় জরুরি নম্বর যোগ",
                    color = NavyPrimary,
                    onClick = { onNavigate(AdminRoutes.AREAS) }
                )
                AdminActionRow(
                    icon = Icons.Rounded.NotificationsActive,
                    title = "সবাইকে নোটিফিকেশন পাঠান",
                    subtitle = "জরুরি ঘোষণা ও আপডেট এক ক্লিকে ব্রডকাস্ট করুন",
                    color = WarningAmber,
                    onClick = { onNavigate(AdminRoutes.BROADCAST) }
                )
                AdminActionRow(
                    icon = Icons.Rounded.People,
                    title = "ব্যবহারকারী, রক্তদাতা ও হারানো-প্রাপ্তি",
                    subtitle = "সদস্য তালিকা ও হারানো-প্রাপ্তি মডারেশন",
                    color = InfoBlue,
                    onClick = { onNavigate(AdminRoutes.USERS_DONORS) }
                )
            }
        }
    }

    if (showLogoutDialog) {
        AlertDialog(
            onDismissRequest = { showLogoutDialog = false },
            title = { Text("লগআউট করবেন?") },
            text = { Text("আপনি কি JANAPAD ADMIN প্যানেল থেকে লগআউট করতে চান?") },
            confirmButton = {
                TextButton(onClick = {
                    showLogoutDialog = false
                    onLogout()
                }) { Text("লগআউট", color = MaterialTheme.colorScheme.error) }
            },
            dismissButton = {
                TextButton(onClick = { showLogoutDialog = false }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
private fun KpiCard(
    title: String,
    value: String,
    icon: ImageVector,
    accent: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier.size(36.dp).clip(CircleShape).background(accent.copy(alpha = 0.14f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            }
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text(title, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun AdminActionRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    color: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier.size(44.dp).clip(CircleShape).background(color.copy(alpha = 0.13f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = color)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
