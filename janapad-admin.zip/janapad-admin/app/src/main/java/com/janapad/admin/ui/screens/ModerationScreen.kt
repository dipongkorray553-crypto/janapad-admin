package com.janapad.admin.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.admin.data.model.MarketplaceItem
import com.janapad.admin.data.model.PublicPost
import com.janapad.admin.data.model.ResourceState
import com.janapad.admin.ui.components.*
import com.janapad.admin.ui.theme.DangerRed
import com.janapad.admin.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModerationScreen(
    postsState: ResourceState<List<PublicPost>>,
    marketplaceState: ResourceState<List<MarketplaceItem>>,
    onApprovePost: (PublicPost, (Boolean, String) -> Unit) -> Unit,
    onRejectPost: (PublicPost, String, (Boolean, String) -> Unit) -> Unit,
    onDeletePost: (String, (Boolean, String) -> Unit) -> Unit,
    onUpdateMarketplaceStatus: (MarketplaceItem, String, (Boolean, String) -> Unit) -> Unit,
    onDeleteMarketplace: (String, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    var mainTab by remember { mutableIntStateOf(0) }
    var statusFilter by remember { mutableStateOf("pending") }
    var rejectTargetPost by remember { mutableStateOf<PublicPost?>(null) }
    var rejectReason by remember { mutableStateOf("") }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("মডারেশন ও অনুমোদন", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = mainTab) {
                Tab(selected = mainTab == 0, onClick = { mainTab = 0 }, text = { Text("পাবলিক পোস্ট") })
                Tab(selected = mainTab == 1, onClick = { mainTab = 1 }, text = { Text("মার্কেটপ্লেস") })
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("pending" to "পেন্ডিং", "approved" to "অনুমোদিত", "rejected" to "বাতিল").forEach { (code, label) ->
                    FilterChip(
                        selected = statusFilter == code,
                        onClick = { statusFilter = code },
                        label = { Text(label) }
                    )
                }
            }

            if (mainTab == 0) {
                when (postsState) {
                    is ResourceState.Loading -> AdminLoadingView("পোস্ট লোড হচ্ছে...")
                    is ResourceState.Error -> AdminErrorView(postsState.message, onRetry)
                    is ResourceState.Success -> {
                        val list = postsState.data.filter { it.status == statusFilter }
                        if (list.isEmpty()) {
                            AdminEmptyView(Icons.Rounded.Forum, "কোনো পোস্ট নেই", "এই স্ট্যাটাসে কোনো পোস্ট পাওয়া যায়নি।")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(list, key = { it.id }) { post ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                StatusChip(post.category, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                                                ModerationStatusChip(post.status)
                                            }
                                            Text(post.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(post.content, style = MaterialTheme.typography.bodyMedium)
                                            Text(
                                                text = "লেখক: ${post.authorName} (${post.authorPhone.ifBlank { "নম্বর নেই" }}) • ${formatDateBn(post.createdAt)}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                            if (post.rejectionReason.isNotBlank()) {
                                                Text(
                                                    text = "বাতিলের কারণ: ${post.rejectionReason}",
                                                    style = MaterialTheme.typography.bodySmall,
                                                    color = DangerRed
                                                )
                                            }
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (post.status != "approved") {
                                                    Button(
                                                        onClick = {
                                                            onApprovePost(post) { _, msg ->
                                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(Icons.Rounded.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("অনুমোদন")
                                                    }
                                                }
                                                if (post.status != "rejected") {
                                                    OutlinedButton(
                                                        onClick = {
                                                            rejectTargetPost = post
                                                            rejectReason = ""
                                                        },
                                                        modifier = Modifier.weight(1f)
                                                    ) {
                                                        Icon(Icons.Rounded.Close, contentDescription = null, modifier = Modifier.size(16.dp), tint = DangerRed)
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text("বাতিল", color = DangerRed)
                                                    }
                                                }
                                                IconButton(onClick = {
                                                    onDeletePost(post.id) { _, msg ->
                                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                    }
                                                }) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                when (marketplaceState) {
                    is ResourceState.Loading -> AdminLoadingView("বিজ্ঞাপন লোড হচ্ছে...")
                    is ResourceState.Error -> AdminErrorView(marketplaceState.message, onRetry)
                    is ResourceState.Success -> {
                        val list = marketplaceState.data.filter { it.status == statusFilter }
                        if (list.isEmpty()) {
                            AdminEmptyView(Icons.Rounded.Storefront, "কোনো বিজ্ঞাপন নেই", "এই স্ট্যাটাসে কোনো মার্কেটপ্লেস পণ্য নেই।")
                        } else {
                            LazyColumn(
                                contentPadding = PaddingValues(16.dp),
                                verticalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                items(list, key = { it.id }) { item ->
                                    Card(
                                        modifier = Modifier.fillMaxWidth(),
                                        shape = RoundedCornerShape(16.dp),
                                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                        border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                    ) {
                                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                StatusChip("${item.category} • ${item.condition}", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                                                Text("৳ ${item.price}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                                            }
                                            Text(item.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            Text(item.description, style = MaterialTheme.typography.bodySmall)
                                            Text("বিক্রেতা: ${item.sellerName} (${item.sellerPhone}) • ${item.location}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                                if (item.status != "approved") {
                                                    Button(
                                                        onClick = {
                                                            onUpdateMarketplaceStatus(item, "approved") { _, msg ->
                                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                            }
                                                        },
                                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                                        modifier = Modifier.weight(1f)
                                                    ) { Text("অনুমোদন") }
                                                }
                                                if (item.status != "rejected") {
                                                    OutlinedButton(
                                                        onClick = {
                                                            onUpdateMarketplaceStatus(item, "rejected") { _, msg ->
                                                                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                            }
                                                        },
                                                        modifier = Modifier.weight(1f)
                                                    ) { Text("বাতিল", color = DangerRed) }
                                                }
                                                IconButton(onClick = {
                                                    onDeleteMarketplace(item.id) { _, msg ->
                                                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                                    }
                                                }) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    rejectTargetPost?.let { target ->
        AlertDialog(
            onDismissRequest = { rejectTargetPost = null },
            title = { Text("পোস্ট বাতিলের কারণ লিখুন") },
            text = {
                OutlinedTextField(
                    value = rejectReason,
                    onValueChange = { rejectReason = it },
                    label = { Text("কারণ (ব্যবহারকারী দেখতে পাবে)") },
                    minLines = 3,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onRejectPost(target, rejectReason) { _, msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                        rejectTargetPost = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed)
                ) { Text("বাতিল নিশ্চিত করুন", color = Color.White) }
            },
            dismissButton = {
                TextButton(onClick = { rejectTargetPost = null }) { Text("বন্ধ করুন") }
            }
        )
    }
}
