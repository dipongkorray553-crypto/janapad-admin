package com.janapad.admin.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.janapad.admin.data.model.*
import com.janapad.admin.ui.components.*
import com.janapad.admin.ui.theme.DangerRed
import com.janapad.admin.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AreasManagerScreen(
    areasState: ResourceState<List<AreaInfo>>,
    onSaveArea: (AreaInfo, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var showAddArea by remember { mutableStateOf(false) }
    var contactTargetArea by remember { mutableStateOf<AreaInfo?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("এলাকা ও জরুরি নম্বর", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddArea = true },
                icon = { Icon(Icons.Rounded.AddLocationAlt, contentDescription = null) },
                text = { Text("নতুন উপজেলা") }
            )
        }
    ) { padding ->
        Box(modifier = Modifier.fillMaxSize().padding(padding)) {
            when (areasState) {
                is ResourceState.Loading -> AdminLoadingView("এলাকা তালিকা লোড হচ্ছে...")
                is ResourceState.Error -> AdminErrorView(areasState.message, onRetry)
                is ResourceState.Success -> {
                    if (areasState.data.isEmpty()) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            AdminEmptyView(Icons.Rounded.Map, "Firestore-এ কোনো এলাকা নেই", "পাটগ্রাম উপজেলা যুক্ত করতে নিচের বাটনে চাপ দিন।")
                            Button(onClick = {
                                val patgram = AreaInfo(
                                    id = "patgram_lalmonirhat",
                                    division = "রংপুর",
                                    district = "লালমনিরহাট",
                                    upazila = "পাটগ্রাম",
                                    isActive = true,
                                    description = "পাটগ্রাম উপজেলা, লালমনিরহাট জেলা, রংপুর বিভাগ, বাংলাদেশ।",
                                    unions = listOf(
                                        "পাটগ্রাম পৌরসভা", "পাটগ্রাম ইউনিয়ন", "বুড়িমারী ইউনিয়ন",
                                        "বাউরা ইউনিয়ন", "কুচলিবাড়ী ইউনিয়ন", "জগতবেড় ইউনিয়ন",
                                        "শ্রীরামপুর ইউনিয়ন", "দহগ্রাম ইউনিয়ন", "জোংড়া ইউনিয়ন"
                                    )
                                )
                                onSaveArea(patgram) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                            }) { Text("পাটগ্রাম উপজেলা সেটআপ করুন") }
                        }
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 84.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(areasState.data, key = { it.id }) { area ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text("${area.upazila}, ${area.district}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                            StatusChip("${area.emergencyContacts.size}টি জরুরি নম্বর", MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                                        }
                                        Text("বিভাগ: ${area.division} • ইউনিয়ন: ${area.unions.size}টি", style = MaterialTheme.typography.bodySmall)
                                        area.emergencyContacts.forEach { c ->
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text("• [${c.category}] ${c.name}: ${c.phone}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.weight(1f))
                                                IconButton(onClick = {
                                                    val updated = area.copy(emergencyContacts = area.emergencyContacts.filterNot { it.id == c.id })
                                                    onSaveArea(updated) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                                }) {
                                                    Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed, modifier = Modifier.size(18.dp))
                                                }
                                            }
                                        }
                                        OutlinedButton(onClick = { contactTargetArea = area }) {
                                            Icon(Icons.Rounded.AddCall, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text("স্থানীয় জরুরি নম্বর যোগ করুন")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddArea) {
        var division by remember { mutableStateOf("রংপুর") }
        var district by remember { mutableStateOf("লালমনিরহাট") }
        var upazila by remember { mutableStateOf("") }
        var unionsCsv by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddArea = false },
            title = { Text("নতুন উপজেলা যুক্ত করুন") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = division, onValueChange = { division = it }, label = { Text("বিভাগ *") }, singleLine = true)
                    OutlinedTextField(value = district, onValueChange = { district = it }, label = { Text("জেলা *") }, singleLine = true)
                    OutlinedTextField(value = upazila, onValueChange = { upazila = it }, label = { Text("উপজেলা *") }, singleLine = true)
                    OutlinedTextField(value = unionsCsv, onValueChange = { unionsCsv = it }, label = { Text("ইউনিয়নসমূহ (কমা দিয়ে আলাদা করুন)") }, minLines = 2)
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("সংক্ষিপ্ত পরিচিতি") }, minLines = 2)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (district.isBlank() || upazila.isBlank()) {
                        Toast.makeText(context, "জেলা ও উপজেলার নাম লিখুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val unions = unionsCsv.split(",").map { it.trim() }.filter { it.isNotBlank() }
                    val newArea = AreaInfo(
                        id = "${upazila.trim()}_${district.trim()}".lowercase().replace(" ", "_"),
                        division = division.trim(),
                        district = district.trim(),
                        upazila = upazila.trim(),
                        description = description.trim(),
                        unions = unions
                    )
                    onSaveArea(newArea) { ok, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (ok) showAddArea = false
                    }
                }) { Text("সংরক্ষণ") }
            },
            dismissButton = { TextButton(onClick = { showAddArea = false }) { Text("বাতিল") } }
        )
    }

    contactTargetArea?.let { area ->
        var category by remember { mutableStateOf(AdminCatalog.emergencyCategories.first()) }
        var name by remember { mutableStateOf("") }
        var phone by remember { mutableStateOf("") }
        var address by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { contactTargetArea = null },
            title = { Text("${area.upazila} — জরুরি নম্বর যোগ") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(AdminCatalog.emergencyCategories) { c ->
                            FilterChip(selected = category == c, onClick = { category = c }, label = { Text(c) })
                        }
                    }
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("প্রতিষ্ঠান / সেবার নাম *") }, singleLine = true)
                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("ফোন নম্বর *") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true
                    )
                    OutlinedTextField(value = address, onValueChange = { address = it }, label = { Text("ঠিকানা") }, singleLine = true)
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isBlank() || phone.isBlank()) {
                        Toast.makeText(context, "নাম ও ফোন নম্বর লিখুন।", Toast.LENGTH_SHORT).show()
                        return@Button
                    }
                    val contact = EmergencyContact(
                        id = "em_${System.currentTimeMillis()}",
                        category = category,
                        name = name.trim(),
                        phone = phone.trim(),
                        address = address.trim(),
                        isVerified = true
                    )
                    onSaveArea(area.copy(emergencyContacts = area.emergencyContacts + contact)) { ok, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        if (ok) contactTargetArea = null
                    }
                }) { Text("যুক্ত করুন") }
            },
            dismissButton = { TextButton(onClick = { contactTargetArea = null }) { Text("বাতিল") } }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BroadcastScreen(
    notificationsState: ResourceState<List<AppNotification>>,
    onSendBroadcast: (String, String, String, (Boolean, String) -> Unit) -> Unit,
    onDeleteNotification: (String, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("notice") }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("নোটিফিকেশন ব্রডকাস্ট", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("সকল ব্যবহারকারীর জন্য নতুন বার্তা", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilterChip(selected = type == "notice", onClick = { type = "notice" }, label = { Text("জরুরি নোটিশ") })
                            FilterChip(selected = type == "news", onClick = { type = "news" }, label = { Text("সংবাদ আপডেট") })
                        }
                        OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম *") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("বার্তা *") }, minLines = 3, modifier = Modifier.fillMaxWidth())
                        Button(
                            onClick = {
                                if (title.isBlank() || message.isBlank()) {
                                    Toast.makeText(context, "শিরোনাম ও বার্তা লিখুন।", Toast.LENGTH_SHORT).show()
                                    return@Button
                                }
                                onSendBroadcast(title, message, type) { ok, msg ->
                                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                                    if (ok) {
                                        title = ""
                                        message = ""
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Rounded.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("সবাইকে পাঠান")
                        }
                    }
                }
            }

            item {
                Text("পূর্বের পাঠানো নোটিফিকেশন", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            when (notificationsState) {
                is ResourceState.Loading -> item { AdminLoadingView() }
                is ResourceState.Error -> item { AdminErrorView(notificationsState.message, onRetry) }
                is ResourceState.Success -> {
                    items(notificationsState.data, key = { it.id }) { n ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            border = BorderStroke(0.6.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(n.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                    Text(n.message, style = MaterialTheme.typography.bodySmall)
                                    Text(
                                        text = "${if (n.targetUserId == "all") "সকল ব্যবহারকারী" else "ব্যক্তিগত"} • ${formatDateBn(n.createdAt)}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                IconButton(onClick = {
                                    onDeleteNotification(n.id) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                }) {
                                    Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UsersDonorsScreen(
    usersState: ResourceState<List<UserProfile>>,
    donorsState: ResourceState<List<BloodDonor>>,
    lostFoundState: ResourceState<List<LostFoundItem>>,
    onDeleteLostFound: (String, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("ব্যবহারকারী ও ডিরেক্টরি", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "পেছনে")
                    }
                }
            )
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("ব্যবহারকারী") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("রক্তদাতা") })
                Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("হারানো-প্রাপ্তি") })
            }

            when (tab) {
                0 -> when (usersState) {
                    is ResourceState.Loading -> AdminLoadingView()
                    is ResourceState.Error -> AdminErrorView(usersState.message, onRetry)
                    is ResourceState.Success -> LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(usersState.data, key = { it.uid }) { user ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                        Text(user.name.ifBlank { "নাম নেই" }, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        StatusChip(
                                            if (user.role == "admin") "অ্যাডমিন" else "সদস্য",
                                            if (user.role == "admin") MaterialTheme.colorScheme.secondaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                            MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Text("${user.email} • ${user.phone}", style = MaterialTheme.typography.bodySmall)
                                    Text("${user.union}, ${user.upazila}, ${user.district}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                1 -> when (donorsState) {
                    is ResourceState.Loading -> AdminLoadingView()
                    is ResourceState.Error -> AdminErrorView(donorsState.message, onRetry)
                    is ResourceState.Success -> LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(donorsState.data, key = { it.id }) { donor ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${donor.name} (${donor.bloodGroup})", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${donor.union}, ${donor.upazila}", style = MaterialTheme.typography.bodySmall)
                                        Text(
                                            text = if (donor.consentToShowPhone) "ফোন: ${donor.phone}" else "নম্বর গোপন রেখেছেন",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    StatusChip(
                                        if (donor.isAvailable) "প্রস্তুত" else "ব্যস্ত",
                                        if (donor.isAvailable) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                        if (donor.isAvailable) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                }
                else -> when (lostFoundState) {
                    is ResourceState.Loading -> AdminLoadingView()
                    is ResourceState.Error -> AdminErrorView(lostFoundState.message, onRetry)
                    is ResourceState.Success -> LazyColumn(
                        contentPadding = PaddingValues(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(lostFoundState.data, key = { it.id }) { entry ->
                            Card(
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text("${if (entry.type == "lost") "[হারানো]" else "[পাওয়া গেছে]"} ${entry.title}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text("${entry.location} • ${entry.contactPhone}", style = MaterialTheme.typography.bodySmall)
                                    }
                                    IconButton(onClick = {
                                        onDeleteLostFound(entry.id) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                    }) {
                                        Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
