package com.janapad.admin.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.janapad.admin.data.model.AdminCatalog
import com.janapad.admin.data.model.AreaReport
import com.janapad.admin.data.model.ResourceState
import com.janapad.admin.ui.components.*
import com.janapad.admin.ui.theme.DangerRed

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsManagerScreen(
    reportsState: ResourceState<List<AreaReport>>,
    onUpdateReport: (AreaReport, String, String, (Boolean, String) -> Unit) -> Unit,
    onDeleteReport: (String, (Boolean, String) -> Unit) -> Unit,
    onRetry: () -> Unit
) {
    val context = LocalContext.current
    var filterStatus by remember { mutableStateOf("all") }
    var editingReport by remember { mutableStateOf<AreaReport?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("সমস্যা রিপোর্ট ব্যবস্থাপনা", fontWeight = FontWeight.Bold) })
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding)) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    FilterChip(selected = filterStatus == "all", onClick = { filterStatus = "all" }, label = { Text("সব") })
                }
                items(AdminCatalog.reportStatuses) { (code, label) ->
                    FilterChip(selected = filterStatus == code, onClick = { filterStatus = code }, label = { Text(label) })
                }
            }

            when (reportsState) {
                is ResourceState.Loading -> AdminLoadingView("রিপোর্ট লোড হচ্ছে...")
                is ResourceState.Error -> AdminErrorView(reportsState.message, onRetry)
                is ResourceState.Success -> {
                    val list = reportsState.data.filter { filterStatus == "all" || it.status == filterStatus }
                    if (list.isEmpty()) {
                        AdminEmptyView(Icons.Rounded.ReportProblem, "কোনো রিপোর্ট নেই", "এই ফিল্টারে কোনো অভিযোগ পাওয়া যায়নি।")
                    } else {
                        LazyColumn(
                            contentPadding = PaddingValues(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            items(list, key = { it.id }) { report ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                                    border = BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            StatusChip(
                                                AdminCatalog.reportCategoryLabel(report.category),
                                                MaterialTheme.colorScheme.primaryContainer,
                                                MaterialTheme.colorScheme.onPrimaryContainer
                                            )
                                            ReportStatusChip(report.status)
                                        }
                                        Text(report.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text(report.description, style = MaterialTheme.typography.bodyMedium)
                                        Text(
                                            text = "অবস্থান: ${report.locationDetail.ifBlank { report.areaName }}",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Text(
                                            text = "রিপোর্টার: ${report.reporterName} • ${formatDateBn(report.createdAt)}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                        if (report.adminNote.isNotBlank()) {
                                            Text("অ্যাডমিন নোট: ${report.adminNote}", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = { editingReport = report },
                                                modifier = Modifier.weight(1f)
                                            ) {
                                                Icon(Icons.Rounded.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text("স্ট্যাটাস আপডেট")
                                            }
                                            IconButton(onClick = {
                                                onDeleteReport(report.id) { _, msg -> Toast.makeText(context, msg, Toast.LENGTH_SHORT).show() }
                                            }) {
                                                Icon(Icons.Rounded.Delete, contentDescription = "মুছুন", tint = DangerRed)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    editingReport?.let { rep ->
        var chosenStatus by remember(rep) { mutableStateOf(rep.status) }
        var note by remember(rep) { mutableStateOf(rep.adminNote) }

        AlertDialog(
            onDismissRequest = { editingReport = null },
            title = { Text("রিপোর্ট স্ট্যাটাস আপডেট") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(AdminCatalog.reportStatuses) { (code, label) ->
                            FilterChip(selected = chosenStatus == code, onClick = { chosenStatus = code }, label = { Text(label) })
                        }
                    }
                    OutlinedTextField(
                        value = note,
                        onValueChange = { note = it },
                        label = { Text("অ্যাডমিন মন্তব্য (ব্যবহারকারী দেখতে পাবে)") },
                        minLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    onUpdateReport(rep, chosenStatus, note) { _, msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                    editingReport = null
                }) { Text("আপডেট করুন") }
            },
            dismissButton = { TextButton(onClick = { editingReport = null }) { Text("বাতিল") } }
        )
    }
}
