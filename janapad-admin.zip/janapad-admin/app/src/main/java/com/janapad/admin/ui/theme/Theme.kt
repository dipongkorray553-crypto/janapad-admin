package com.janapad.admin.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.googlefonts.Font
import androidx.compose.ui.text.googlefonts.GoogleFont
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import com.janapad.admin.R
import com.janapad.admin.data.model.ThemeMode

val NavyPrimary = Color(0xFF102A43)
val NavyDark = Color(0xFF0A1D2E)
val NavyLight = Color(0xFF486581)
val GoldAccent = Color(0xFFE6A817)
val SuccessGreen = Color(0xFF1B873F)
val DangerRed = Color(0xFFC62828)
val InfoBlue = Color(0xFF1565C0)
val WarningAmber = Color(0xFFD97706)

private val LightColors = lightColorScheme(
    primary = NavyPrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFD9E6F2),
    onPrimaryContainer = NavyDark,
    secondary = GoldAccent,
    onSecondary = Color(0xFF1F1600),
    secondaryContainer = Color(0xFFFFF1CC),
    onSecondaryContainer = Color(0xFF3E2B00),
    error = DangerRed,
    onError = Color.White,
    errorContainer = Color(0xFFFFEBEE),
    onErrorContainer = DangerRed,
    background = Color(0xFFF4F6F9),
    onBackground = Color(0xFF101820),
    surface = Color.White,
    onSurface = Color(0xFF101820),
    surfaceVariant = Color(0xFFE9EEF4),
    onSurfaceVariant = Color(0xFF485766),
    outline = Color(0xFFCFD9E3)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF82B1FF),
    onPrimary = Color(0xFF002147),
    primaryContainer = Color(0xFF16324F),
    onPrimaryContainer = Color(0xFFD9E6F2),
    secondary = GoldAccent,
    onSecondary = Color(0xFF281C00),
    secondaryContainer = Color(0xFF3E2D00),
    onSecondaryContainer = Color(0xFFFFF1CC),
    error = Color(0xFFEF5350),
    onError = Color(0xFF3E0004),
    errorContainer = Color(0xFF4A1215),
    onErrorContainer = Color(0xFFFFCDD2),
    background = Color(0xFF0D141C),
    onBackground = Color(0xFFEBF1F7),
    surface = Color(0xFF141E29),
    onSurface = Color(0xFFEBF1F7),
    surfaceVariant = Color(0xFF1D2B3A),
    onSurfaceVariant = Color(0xFFA6B6C7),
    outline = Color(0xFF2D3E50)
)

private val fontProvider = GoogleFont.Provider(
    providerAuthority = "com.google.android.gms.fonts",
    providerPackage = "com.google.android.gms",
    certificates = R.array.com_google_android_gms_fonts_certs
)

private val hindSiliguri = FontFamily(
    Font(GoogleFont("Hind Siliguri"), fontProvider, FontWeight.Normal),
    Font(GoogleFont("Hind Siliguri"), fontProvider, FontWeight.Medium),
    Font(GoogleFont("Hind Siliguri"), fontProvider, FontWeight.SemiBold),
    Font(GoogleFont("Hind Siliguri"), fontProvider, FontWeight.Bold)
)

private val AdminTypography = Typography(
    displaySmall = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Bold, fontSize = 26.sp, lineHeight = 34.sp),
    headlineMedium = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Bold, fontSize = 21.sp, lineHeight = 28.sp),
    headlineSmall = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.SemiBold, fontSize = 18.sp, lineHeight = 25.sp),
    titleLarge = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 24.sp),
    titleMedium = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 22.sp),
    titleSmall = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Medium, fontSize = 14.sp, lineHeight = 20.sp),
    bodyLarge = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Normal, fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Normal, fontSize = 14.sp, lineHeight = 20.sp),
    bodySmall = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Normal, fontSize = 12.sp, lineHeight = 18.sp),
    labelLarge = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, lineHeight = 18.sp),
    labelMedium = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp),
    labelSmall = TextStyle(fontFamily = hindSiliguri, fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp)
)

@Composable
fun JanapadAdminTheme(
    themeMode: ThemeMode = ThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val darkTheme = when (themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    val colors = if (darkTheme) DarkColors else LightColors
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                window.statusBarColor = Color.Transparent.toArgb()
                window.navigationBarColor = Color.Transparent.toArgb()
                WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !darkTheme
                WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !darkTheme
            }
        }
    }
    MaterialTheme(colorScheme = colors, typography = AdminTypography, content = content)
}
