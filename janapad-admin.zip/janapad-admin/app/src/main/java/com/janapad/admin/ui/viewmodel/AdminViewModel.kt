package com.janapad.admin.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.janapad.admin.data.local.PreferencesManager
import com.janapad.admin.data.model.*
import com.janapad.admin.data.repository.AdminAuthRepository
import com.janapad.admin.data.repository.AdminRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class AdminAuthUiState(
    val isFirebaseReady: Boolean = false,
    val isCheckingSession: Boolean = true,
    val isAuthenticatedAdmin: Boolean = false,
    val isLoading: Boolean = false,
    val adminProfile: UserProfile? = null,
    val errorMessage: String? = null
)

class AdminViewModel(application: Application) : AndroidViewModel(application) {

    private val authRepo = AdminAuthRepository(application.applicationContext)
    private val repo = AdminRepository(application.applicationContext)
    private val prefs = PreferencesManager(application.applicationContext)

    val themeMode: StateFlow<ThemeMode> = prefs.themeModeFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), ThemeMode.SYSTEM)

    private val _authState = MutableStateFlow(AdminAuthUiState(isFirebaseReady = authRepo.isFirebaseReady))
    val authState: StateFlow<AdminAuthUiState> = _authState.asStateFlow()

    private val _posts = MutableStateFlow<ResourceState<List<PublicPost>>>(ResourceState.Loading)
    val posts: StateFlow<ResourceState<List<PublicPost>>> = _posts.asStateFlow()

    private val _news = MutableStateFlow<ResourceState<List<NewsItem>>>(ResourceState.Loading)
    val news: StateFlow<ResourceState<List<NewsItem>>> = _news.asStateFlow()

    private val _notices = MutableStateFlow<ResourceState<List<NoticeItem>>>(ResourceState.Loading)
    val notices: StateFlow<ResourceState<List<NoticeItem>>> = _notices.asStateFlow()

    private val _jobs = MutableStateFlow<ResourceState<List<JobListing>>>(ResourceState.Loading)
    val jobs: StateFlow<ResourceState<List<JobListing>>> = _jobs.asStateFlow()

    private val _marketplace = MutableStateFlow<ResourceState<List<MarketplaceItem>>>(ResourceState.Loading)
    val marketplace: StateFlow<ResourceState<List<MarketplaceItem>>> = _marketplace.asStateFlow()

    private val _reports = MutableStateFlow<ResourceState<List<AreaReport>>>(ResourceState.Loading)
    val reports: StateFlow<ResourceState<List<AreaReport>>> = _reports.asStateFlow()

    private val _areas = MutableStateFlow<ResourceState<List<AreaInfo>>>(ResourceState.Loading)
    val areas: StateFlow<ResourceState<List<AreaInfo>>> = _areas.asStateFlow()

    private val _notifications = MutableStateFlow<ResourceState<List<AppNotification>>>(ResourceState.Loading)
    val notifications: StateFlow<ResourceState<List<AppNotification>>> = _notifications.asStateFlow()

    private val _users = MutableStateFlow<ResourceState<List<UserProfile>>>(ResourceState.Loading)
    val users: StateFlow<ResourceState<List<UserProfile>>> = _users.asStateFlow()

    private val _bloodDonors = MutableStateFlow<ResourceState<List<BloodDonor>>>(ResourceState.Loading)
    val bloodDonors: StateFlow<ResourceState<List<BloodDonor>>> = _bloodDonors.asStateFlow()

    private val _lostFound = MutableStateFlow<ResourceState<List<LostFoundItem>>>(ResourceState.Loading)
    val lostFound: StateFlow<ResourceState<List<LostFoundItem>>> = _lostFound.asStateFlow()

    private val listenerJobs = mutableListOf<Job>()

    init {
        checkSession()
    }

    private fun checkSession() {
        viewModelScope.launch {
            if (!authRepo.isFirebaseReady) {
                _authState.value = _authState.value.copy(
                    isFirebaseReady = false,
                    isCheckingSession = false,
                    isAuthenticatedAdmin = false
                )
                return@launch
            }
            authRepo.verifyCurrentAdminSession()
                .onSuccess { profile ->
                    if (profile != null) {
                        _authState.value = _authState.value.copy(
                            isCheckingSession = false,
                            isAuthenticatedAdmin = true,
                            adminProfile = profile,
                            errorMessage = null
                        )
                        startListeners()
                    } else {
                        _authState.value = _authState.value.copy(
                            isCheckingSession = false,
                            isAuthenticatedAdmin = false,
                            adminProfile = null
                        )
                    }
                }
                .onFailure { err ->
                    _authState.value = _authState.value.copy(
                        isCheckingSession = false,
                        isAuthenticatedAdmin = false,
                        adminProfile = null,
                        errorMessage = err.message
                    )
                }
        }
    }

    fun loginAdmin(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) {
            _authState.value = _authState.value.copy(errorMessage = "ইমেইল এবং পাসওয়ার্ড উভয়ই লিখুন।")
            return
        }
        viewModelScope.launch {
            _authState.value = _authState.value.copy(isLoading = true, errorMessage = null)
            authRepo.loginAdmin(email, password)
                .onSuccess { profile ->
                    _authState.value = _authState.value.copy(
                        isLoading = false,
                        isAuthenticatedAdmin = true,
                        adminProfile = profile,
                        errorMessage = null
                    )
                    startListeners()
                }
                .onFailure { err ->
                    _authState.value = _authState.value.copy(
                        isLoading = false,
                        isAuthenticatedAdmin = false,
                        errorMessage = err.message ?: "অ্যাডমিন লগইন ব্যর্থ হয়েছে।"
                    )
                }
        }
    }

    fun logout() {
        listenerJobs.forEach { it.cancel() }
        listenerJobs.clear()
        authRepo.logout()
        _authState.value = _authState.value.copy(
            isAuthenticatedAdmin = false,
            adminProfile = null,
            errorMessage = null
        )
    }

    fun startListeners() {
        listenerJobs.forEach { it.cancel() }
        listenerJobs.clear()
        listenerJobs += viewModelScope.launch { repo.observePosts().collect { _posts.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeNews().collect { _news.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeNotices().collect { _notices.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeJobs().collect { _jobs.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeMarketplace().collect { _marketplace.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeReports().collect { _reports.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeAreas().collect { _areas.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeNotifications().collect { _notifications.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeUsers().collect { _users.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeBloodDonors().collect { _bloodDonors.value = it } }
        listenerJobs += viewModelScope.launch { repo.observeLostFound().collect { _lostFound.value = it } }
    }

    fun setThemeMode(mode: ThemeMode) {
        viewModelScope.launch { prefs.setThemeMode(mode) }
    }

    fun approvePost(post: PublicPost, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.updatePostStatus(post, "approved")
                .onSuccess { onDone(true, "পোস্ট অনুমোদিত হয়েছে এবং ব্যবহারকারীকে জানানো হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun rejectPost(post: PublicPost, reason: String, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.updatePostStatus(post, "rejected", reason)
                .onSuccess { onDone(true, "পোস্ট বাতিল করা হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun deleteDoc(collection: String, id: String, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.deleteDocument(collection, id)
                .onSuccess { onDone(true, "সফলভাবে মুছে ফেলা হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "মুছে ফেলা যায়নি।") }
        }
    }

    fun saveNews(item: NewsItem, broadcast: Boolean, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.saveNews(item, broadcast)
                .onSuccess { onDone(true, "সংবাদ প্রকাশিত হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "সংরক্ষণ ব্যর্থ।") }
        }
    }

    fun toggleNewsPin(newsId: String, pinned: Boolean) {
        viewModelScope.launch { repo.toggleNewsPin(newsId, pinned) }
    }

    fun saveNotice(item: NoticeItem, broadcast: Boolean, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.saveNotice(item, broadcast)
                .onSuccess { onDone(true, "নোটিশ প্রকাশিত হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun saveJob(item: JobListing, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.saveJob(item)
                .onSuccess { onDone(true, "চাকরির বিজ্ঞপ্তি প্রকাশিত হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun toggleJobActive(jobId: String, active: Boolean) {
        viewModelScope.launch { repo.toggleJobActive(jobId, active) }
    }

    fun updateMarketplaceStatus(item: MarketplaceItem, status: String, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.updateMarketplaceStatus(item, status)
                .onSuccess { onDone(true, "বিজ্ঞাপনের স্ট্যাটাস আপডেট হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun updateReportStatus(report: AreaReport, status: String, adminNote: String, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.updateReportStatus(report, status, adminNote)
                .onSuccess { onDone(true, "রিপোর্টের স্ট্যাটাস আপডেট হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun saveArea(area: AreaInfo, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.saveArea(area)
                .onSuccess { onDone(true, "এলাকার তথ্য সংরক্ষিত হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "ব্যর্থ হয়েছে।") }
        }
    }

    fun sendBroadcast(title: String, message: String, type: String, onDone: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            repo.sendBroadcastNotification(title, message, type)
                .onSuccess { onDone(true, "সব ব্যবহারকারীর কাছে নোটিফিকেশন পাঠানো হয়েছে।") }
                .onFailure { onDone(false, it.message ?: "পাঠানো যায়নি।") }
        }
    }
}
